# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: aprenda.spec.ts >> aba Aprenda abre os guias e permite filtrar conteúdos
- Location: e2e\aprenda.spec.ts:3:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: '5 sinais de alerta para evitar golpes com NFTs' })
Expected: visible
Error: strict mode violation: getByRole('heading', { name: '5 sinais de alerta para evitar golpes com NFTs' }) resolved to 2 elements:
    1) <h2 id="learn-reader-title">5 sinais de alerta para evitar golpes com NFTs</h2> aka locator('#learn-reader-title')
    2) <h3>5 sinais de alerta para evitar golpes com NFTs</h3> aka locator('h3').filter({ hasText: '5 sinais de alerta para' })

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: '5 sinais de alerta para evitar golpes com NFTs' }) with timeout 5000ms
  - waiting for getByRole('heading', { name: '5 sinais de alerta para evitar golpes com NFTs' })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Ir para o conteúdo" [ref=e4] [cursor=pointer]:
    - /url: "#conteudo"
  - main [ref=e5]:
    - main [ref=e6]:
      - generic [ref=e7]:
        - generic [ref=e8]:
          - generic [ref=e9]: CENTRAL DE CONHECIMENTO KURIO
          - heading [level=1] [ref=e12]:
            - text: Descubra.
            - emphasis [ref=e13]: Entenda.
            - text: Colecione com confiança.
          - paragraph [ref=e14]: Guias diretos para explorar NFTs, proteger sua carteira e dar os próximos passos como artista ou colecionador.
          - link "EXPLORAR CONTEÚDOS" [ref=e15] [cursor=pointer]:
            - /url: "#biblioteca"
        - generic [ref=e22]:
          - generic [ref=e28]: K.
          - generic [ref=e29]: APRENDA NO SEU RITMO
      - region "Trilhas de aprendizado" [ref=e30]:
        - link "Quero colecionar Conheça NFTs, carteiras e como pesquisar uma coleção." [ref=e31] [cursor=pointer]:
          - /url: /mercado
          - generic [ref=e36]:
            - strong [ref=e37]: Quero colecionar
            - generic [ref=e38]: Conheça NFTs, carteiras e como pesquisar uma coleção.
        - link "Quero criar Aprenda sobre cunhagem, apresentação e direitos da obra." [ref=e41] [cursor=pointer]:
          - /url: /criadores
          - generic [ref=e46]:
            - strong [ref=e47]: Quero criar
            - generic [ref=e48]: Aprenda sobre cunhagem, apresentação e direitos da obra.
        - link "Quero me proteger Veja boas práticas para manter sua carteira segura." [ref=e51] [cursor=pointer]:
          - /url: "#seguranca"
          - generic [ref=e56]:
            - strong [ref=e57]: Quero me proteger
            - generic [ref=e58]: Veja boas práticas para manter sua carteira segura.
      - generic [ref=e61]:
        - generic [ref=e62]:
          - generic [ref=e63]:
            - generic [ref=e64]: DIÁRIO DA CUNHAGEM
            - heading [level=2] [ref=e65]:
              - text: Conhecimento que
              - emphasis [ref=e66]: abre caminhos.
            - paragraph [ref=e67]: Conteúdo prático para tomar decisões mais conscientes no universo digital.
          - generic [ref=e68]:
            - generic [ref=e69]: Buscar artigos
            - searchbox "Buscar artigos" [ref=e70]
            - generic [aria-hidden] [ref=e71]: ⌕
        - generic "Filtrar por assunto" [ref=e72]:
          - button "Todos" [ref=e73] [cursor=pointer]
          - button "Começando" [ref=e74] [cursor=pointer]
          - button "Colecionadores" [ref=e75] [cursor=pointer]
          - button "Criadores" [ref=e76] [cursor=pointer]
          - button "Segurança" [pressed] [ref=e77] [cursor=pointer]
        - region [ref=e78]:
          - button "Fechar artigo" [ref=e79] [cursor=pointer]
          - generic [ref=e83]: Segurança · LEITURA DE 4 MIN
          - heading "5 sinais de alerta para evitar golpes com NFTs" [level=2] [ref=e84]
          - paragraph [ref=e85]: Nunca compartilhe sua frase de recuperação ou chave privada, mesmo que a pessoa alegue trabalhar na plataforma.
          - paragraph [ref=e86]: Confira o endereço do site antes de conectar sua carteira. Evite links recebidos inesperadamente e anúncios que imitam projetos conhecidos.
          - paragraph [ref=e87]: Leia a solicitação da carteira com atenção. Se não entender o que está autorizando, cancele e procure a documentação oficial por conta própria.
          - generic [ref=e88]:
            - strong [ref=e89]: PARA LEMBRAR
            - paragraph [ref=e90]: Pare, confira por outro canal e não assine uma transação sob pressão.
        - article [ref=e92]:
          - generic [ref=e93]: Segurança
          - generic [ref=e95]:
            - generic [ref=e96]: LEITURA DE 4 MIN
            - heading "5 sinais de alerta para evitar golpes com NFTs" [level=3] [ref=e97]
            - paragraph [ref=e98]: Links falsos, suporte que pede segredo, promessas de lucro e outras armadilhas comuns.
            - button "LER ARTIGO" [active] [ref=e99] [cursor=pointer]
      - generic [ref=e102]:
        - generic [ref=e107]:
          - generic [ref=e108]: SEGURANÇA EM PRIMEIRO LUGAR
          - heading [level=2] [ref=e109]:
            - text: Se parece urgente demais,
            - emphasis [ref=e110]: desconfie.
          - paragraph [ref=e111]: Nunca compartilhe sua frase de recuperação, confira links antes de conectar sua carteira e não assine transações que você não entende. Conteúdo educativo não é recomendação financeira.
        - link "VER GUIAS DE SEGURANÇA" [ref=e112] [cursor=pointer]:
          - /url: "#biblioteca"
      - generic [ref=e115]:
        - generic [ref=e116]:
          - generic [ref=e117]: SEU PRÓXIMO PASSO
          - heading "Aprendeu o básico? Explore o universo Kurio." [level=2] [ref=e118]
          - paragraph [ref=e119]: Descubra coleções e artistas, sempre no seu ritmo.
        - generic [ref=e120]:
          - link "EXPLORAR MERCADO" [ref=e121] [cursor=pointer]:
            - /url: /mercado
          - link "CONHECER CRIADORES" [ref=e124] [cursor=pointer]:
            - /url: /criadores
  - navigation "Navegação mobile" [ref=e127]:
    - link "Início" [ref=e128] [cursor=pointer]:
      - /url: /
    - link "Mercado" [ref=e132] [cursor=pointer]:
      - /url: /mercado
    - link "Criadores" [ref=e136] [cursor=pointer]:
      - /url: /criadores
    - link "Aprenda" [ref=e141] [cursor=pointer]:
      - /url: /aprenda
    - link "Carrinho de compras" [ref=e144] [cursor=pointer]:
      - /url: /carrinho
      - text: Carrinho
    - link "Entrar" [ref=e150] [cursor=pointer]:
      - /url: /login
      - text: Perfil
  - contentinfo [ref=e154]:
    - generic [ref=e155]:
      - article [ref=e156]:
        - generic [ref=e157]: W
        - heading "Segurança da carteira" [level=3] [ref=e158]
        - paragraph [ref=e159]: Proteja sua carteira e colecione arte digital verificada com confiança.
      - article [ref=e160]:
        - generic [ref=e161]: C
        - heading "Criadores em destaque" [level=3] [ref=e162]
        - paragraph [ref=e163]: Conheça artistas, estúdios e comunidades que moldam a cultura digital na rede.
      - article [ref=e164]:
        - generic [ref=e165]: D
        - heading "Alertas de lançamentos" [level=3] [ref=e166]
        - paragraph [ref=e167]: Receba calendários de cunhagem, novidades de listas de acesso e análises do mercado.
    - generic [ref=e168]:
      - strong [ref=e169]: KURIO
      - generic [ref=e170]: Feito para colecionadores,criadores e cultura
      - generic [ref=e171]: contato@email.com
      - generic [ref=e172]: +55 11 4002 8922
    - generic [ref=e173]:
      - generic [ref=e174]:
        - heading "Meu perfil" [level=3] [ref=e175]
        - link "Meu perfil" [ref=e176] [cursor=pointer]:
          - /url: /perfil
        - link "Carteiras" [ref=e177] [cursor=pointer]:
          - /url: /carteiras
      - generic [ref=e178]:
        - heading "Mercado" [level=3] [ref=e179]
        - link "Início" [ref=e180] [cursor=pointer]:
          - /url: /
        - link "Explorar NFTs" [ref=e181] [cursor=pointer]:
          - /url: /#catalogo
        - link "Criadores" [ref=e182] [cursor=pointer]:
          - /url: /criadores
      - generic [ref=e183]:
        - heading "Coleções" [level=3] [ref=e184]
        - link "Arte digital" [ref=e185] [cursor=pointer]:
          - /url: /?categoria=%5B%22arte-digital%22%5D&pagina=1
        - link "Fotografia" [ref=e186] [cursor=pointer]:
          - /url: /?categoria=%5B%22fotografia%22%5D&pagina=1
        - link "Música" [ref=e187] [cursor=pointer]:
          - /url: /?categoria=%5B%22musica%22%5D&pagina=1
        - link "Arte 3D" [ref=e188] [cursor=pointer]:
          - /url: /?categoria=%5B%22arte-3d%22%5D&pagina=1
        - link "Colecionáveis" [ref=e189] [cursor=pointer]:
          - /url: /?categoria=%5B%22colecionaveis%22%5D&pagina=1
        - link "Generativa" [ref=e190] [cursor=pointer]:
          - /url: /?categoria=%5B%22generativa%22%5D&pagina=1
        - link "Jogos" [ref=e191] [cursor=pointer]:
          - /url: /?categoria=%5B%22jogos%22%5D&pagina=1
        - link "Assinaturas" [ref=e192] [cursor=pointer]:
          - /url: /?categoria=%5B%22assinaturas%22%5D&pagina=1
        - link "Utilidade" [ref=e193] [cursor=pointer]:
          - /url: /?categoria=%5B%22utilidade%22%5D&pagina=1
      - generic [ref=e194]:
        - heading "Carteiras compatíveis" [level=3] [ref=e195]
        - generic [ref=e196]:
          - generic [ref=e197]: METAMASK
          - generic [ref=e198]: â€¢WALLETCONNECT
          - generic [ref=e199]: â€¢COINBASE
    - generic [ref=e200]: © 2026 Kurio. Propriedade digital para todos.
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | 
  3  | test("aba Aprenda abre os guias e permite filtrar conteúdos", async ({ page }) => {
  4  |   await page.goto("/aprenda");
  5  | 
  6  |   await expect(
  7  |     page.getByRole("heading", { name: /Descubra\./i }),
  8  |   ).toBeVisible();
  9  |   await expect(page.getByText("DIÁRIO DA CUNHAGEM")).toBeVisible();
  10 |   await expect(
  11 |     page.getByRole("searchbox", { name: "Buscar artigos" }),
  12 |   ).toBeVisible();
  13 | 
  14 |   await page.getByRole("button", { name: "Segurança" }).click();
  15 |   await expect(
  16 |     page.getByRole("heading", {
  17 |       name: "5 sinais de alerta para evitar golpes com NFTs",
  18 |     }),
  19 |   ).toBeVisible();
  20 |   await expect(
  21 |     page.getByRole("heading", { name: "Sua primeira carteira digital" }),
  22 |   ).toHaveCount(0);
  23 | 
  24 |   await page.getByRole("button", { name: "LER ARTIGO" }).last().click();
  25 |   await expect(
  26 |     page.getByRole("heading", {
  27 |       name: "5 sinais de alerta para evitar golpes com NFTs",
  28 |     }),
> 29 |   ).toBeVisible();
     |     ^ Error: expect(locator).toBeVisible() failed
  30 |   await expect(page.getByText("PARA LEMBRAR")).toBeVisible();
  31 | });
  32 | 
```