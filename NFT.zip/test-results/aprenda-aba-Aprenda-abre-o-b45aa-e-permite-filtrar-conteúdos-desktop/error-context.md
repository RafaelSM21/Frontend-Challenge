# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: aprenda.spec.ts >> aba Aprenda abre os guias e permite filtrar conteúdos
- Location: e2e\aprenda.spec.ts:3:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: '5 sinais de alerta para evitar golpes com NFTs' })
Expected: visible
Error: strict mode violation: getByRole('heading', { name: '5 sinais de alerta para evitar golpes com NFTs' }) resolved to 2 elements:
    1) <h2 id="learn-reader-title">5 sinais de alerta para evitar golpes com NFTs</h2> aka locator('#learn-reader-title')
    2) <h3>5 sinais de alerta para evitar golpes com NFTs</h3> aka locator('h3').filter({ hasText: '5 sinais de alerta para' })

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: '5 sinais de alerta para evitar golpes com NFTs' }) with timeout 5000ms
  - waiting for getByRole('heading', { name: '5 sinais de alerta para evitar golpes com NFTs' })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Ir para o conteúdo" [ref=e4] [cursor=pointer]:
    - /url: "#conteudo"
  - banner [ref=e5]:
    - navigation "Principal" [ref=e6]:
      - link "Kurio, página inicial" [ref=e7] [cursor=pointer]:
        - /url: /
        - generic [ref=e8]: KURIO
      - generic [ref=e9]:
        - link "Início" [ref=e10] [cursor=pointer]:
          - /url: /
        - link "Mercado" [ref=e11] [cursor=pointer]:
          - /url: /mercado
        - link "Criadores" [ref=e12] [cursor=pointer]:
          - /url: /criadores
        - link "Aprenda" [ref=e13] [cursor=pointer]:
          - /url: /aprenda
      - generic [ref=e14]:
        - button "Buscar obras" [ref=e16] [cursor=pointer]
        - link "Carrinho de compras, 0 itens" [ref=e18] [cursor=pointer]:
          - /url: /carrinho
          - generic [ref=e20]: "0"
        - link "Entrar" [ref=e21] [cursor=pointer]:
          - /url: /login
  - main [ref=e22]:
    - main [ref=e23]:
      - generic [ref=e24]:
        - generic [ref=e25]:
          - generic [ref=e26]: CENTRAL DE CONHECIMENTO KURIO
          - heading [level=1] [ref=e29]:
            - text: Descubra.
            - emphasis [ref=e30]: Entenda.
            - text: Colecione com confiança.
          - paragraph [ref=e31]: Guias diretos para explorar NFTs, proteger sua carteira e dar os próximos passos como artista ou colecionador.
          - link "EXPLORAR CONTEÚDOS" [ref=e32] [cursor=pointer]:
            - /url: "#biblioteca"
        - generic [ref=e39]:
          - generic [ref=e45]: K.
          - generic [ref=e46]: APRENDA NO SEU RITMO
      - region "Trilhas de aprendizado" [ref=e47]:
        - link "Quero colecionar Conheça NFTs, carteiras e como pesquisar uma coleção." [ref=e48] [cursor=pointer]:
          - /url: /mercado
          - generic [ref=e53]:
            - strong [ref=e54]: Quero colecionar
            - generic [ref=e55]: Conheça NFTs, carteiras e como pesquisar uma coleção.
        - link "Quero criar Aprenda sobre cunhagem, apresentação e direitos da obra." [ref=e58] [cursor=pointer]:
          - /url: /criadores
          - generic [ref=e63]:
            - strong [ref=e64]: Quero criar
            - generic [ref=e65]: Aprenda sobre cunhagem, apresentação e direitos da obra.
        - link "Quero me proteger Veja boas práticas para manter sua carteira segura." [ref=e68] [cursor=pointer]:
          - /url: "#seguranca"
          - generic [ref=e73]:
            - strong [ref=e74]: Quero me proteger
            - generic [ref=e75]: Veja boas práticas para manter sua carteira segura.
      - generic [ref=e78]:
        - generic [ref=e79]:
          - generic [ref=e80]:
            - generic [ref=e81]: DIÁRIO DA CUNHAGEM
            - heading [level=2] [ref=e82]:
              - text: Conhecimento que
              - emphasis [ref=e83]: abre caminhos.
            - paragraph [ref=e84]: Conteúdo prático para tomar decisões mais conscientes no universo digital.
          - generic [ref=e85]:
            - generic [ref=e86]: Buscar artigos
            - searchbox "Buscar artigos" [ref=e87]
            - generic [aria-hidden] [ref=e88]: ⌕
        - generic "Filtrar por assunto" [ref=e89]:
          - button "Todos" [ref=e90] [cursor=pointer]
          - button "Começando" [ref=e91] [cursor=pointer]
          - button "Colecionadores" [ref=e92] [cursor=pointer]
          - button "Criadores" [ref=e93] [cursor=pointer]
          - button "Segurança" [pressed] [ref=e94] [cursor=pointer]
        - region [ref=e95]:
          - button "Fechar artigo" [ref=e96] [cursor=pointer]
          - generic [ref=e100]: Segurança · LEITURA DE 4 MIN
          - heading "5 sinais de alerta para evitar golpes com NFTs" [level=2] [ref=e101]
          - paragraph [ref=e102]: Nunca compartilhe sua frase de recuperação ou chave privada, mesmo que a pessoa alegue trabalhar na plataforma.
          - paragraph [ref=e103]: Confira o endereço do site antes de conectar sua carteira. Evite links recebidos inesperadamente e anúncios que imitam projetos conhecidos.
          - paragraph [ref=e104]: Leia a solicitação da carteira com atenção. Se não entender o que está autorizando, cancele e procure a documentação oficial por conta própria.
          - generic [ref=e105]:
            - strong [ref=e106]: PARA LEMBRAR
            - paragraph [ref=e107]: Pare, confira por outro canal e não assine uma transação sob pressão.
        - article [ref=e109]:
          - generic [ref=e110]: Segurança
          - generic [ref=e112]:
            - generic [ref=e113]: LEITURA DE 4 MIN
            - heading "5 sinais de alerta para evitar golpes com NFTs" [level=3] [ref=e114]
            - paragraph [ref=e115]: Links falsos, suporte que pede segredo, promessas de lucro e outras armadilhas comuns.
            - button "LER ARTIGO" [active] [ref=e116] [cursor=pointer]
      - generic [ref=e119]:
        - generic [ref=e124]:
          - generic [ref=e125]: SEGURANÇA EM PRIMEIRO LUGAR
          - heading [level=2] [ref=e126]:
            - text: Se parece urgente demais,
            - emphasis [ref=e127]: desconfie.
          - paragraph [ref=e128]: Nunca compartilhe sua frase de recuperação, confira links antes de conectar sua carteira e não assine transações que você não entende. Conteúdo educativo não é recomendação financeira.
        - link "VER GUIAS DE SEGURANÇA" [ref=e129] [cursor=pointer]:
          - /url: "#biblioteca"
      - generic [ref=e132]:
        - generic [ref=e133]:
          - generic [ref=e134]: SEU PRÓXIMO PASSO
          - heading "Aprendeu o básico? Explore o universo Kurio." [level=2] [ref=e135]
          - paragraph [ref=e136]: Descubra coleções e artistas, sempre no seu ritmo.
        - generic [ref=e137]:
          - link "EXPLORAR MERCADO" [ref=e138] [cursor=pointer]:
            - /url: /mercado
          - link "CONHECER CRIADORES" [ref=e141] [cursor=pointer]:
            - /url: /criadores
  - contentinfo [ref=e144]:
    - generic [ref=e145]:
      - article [ref=e146]:
        - generic [ref=e147]: W
        - heading "Segurança da carteira" [level=3] [ref=e148]
        - paragraph [ref=e149]: Proteja sua carteira e colecione arte digital verificada com confiança.
      - article [ref=e150]:
        - generic [ref=e151]: C
        - heading "Criadores em destaque" [level=3] [ref=e152]
        - paragraph [ref=e153]: Conheça artistas, estúdios e comunidades que moldam a cultura digital na rede.
      - article [ref=e154]:
        - generic [ref=e155]: D
        - heading "Alertas de lançamentos" [level=3] [ref=e156]
        - paragraph [ref=e157]: Receba calendários de cunhagem, novidades de listas de acesso e análises do mercado.
    - generic [ref=e158]:
      - strong [ref=e159]: KURIO
      - generic [ref=e160]: Feito para colecionadores,criadores e cultura
      - generic [ref=e161]: contato@email.com
      - generic [ref=e162]: +55 11 4002 8922
    - generic [ref=e163]:
      - generic [ref=e164]:
        - heading "Meu perfil" [level=3] [ref=e165]
        - link "Meu perfil" [ref=e166] [cursor=pointer]:
          - /url: /perfil
        - link "Carteiras" [ref=e167] [cursor=pointer]:
          - /url: /carteiras
      - generic [ref=e168]:
        - heading "Mercado" [level=3] [ref=e169]
        - link "Início" [ref=e170] [cursor=pointer]:
          - /url: /
        - link "Explorar NFTs" [ref=e171] [cursor=pointer]:
          - /url: /#catalogo
        - link "Criadores" [ref=e172] [cursor=pointer]:
          - /url: /criadores
      - generic [ref=e173]:
        - heading "Coleções" [level=3] [ref=e174]
        - link "Arte digital" [ref=e175] [cursor=pointer]:
          - /url: /?categoria=%5B%22arte-digital%22%5D&pagina=1
        - link "Fotografia" [ref=e176] [cursor=pointer]:
          - /url: /?categoria=%5B%22fotografia%22%5D&pagina=1
        - link "Música" [ref=e177] [cursor=pointer]:
          - /url: /?categoria=%5B%22musica%22%5D&pagina=1
        - link "Arte 3D" [ref=e178] [cursor=pointer]:
          - /url: /?categoria=%5B%22arte-3d%22%5D&pagina=1
        - link "Colecionáveis" [ref=e179] [cursor=pointer]:
          - /url: /?categoria=%5B%22colecionaveis%22%5D&pagina=1
        - link "Generativa" [ref=e180] [cursor=pointer]:
          - /url: /?categoria=%5B%22generativa%22%5D&pagina=1
        - link "Jogos" [ref=e181] [cursor=pointer]:
          - /url: /?categoria=%5B%22jogos%22%5D&pagina=1
        - link "Assinaturas" [ref=e182] [cursor=pointer]:
          - /url: /?categoria=%5B%22assinaturas%22%5D&pagina=1
        - link "Utilidade" [ref=e183] [cursor=pointer]:
          - /url: /?categoria=%5B%22utilidade%22%5D&pagina=1
      - generic [ref=e184]:
        - heading "Carteiras compatíveis" [level=3] [ref=e185]
        - generic [ref=e186]:
          - generic [ref=e187]: METAMASK
          - generic [ref=e188]: â€¢WALLETCONNECT
          - generic [ref=e189]: â€¢COINBASE
    - generic [ref=e190]: © 2026 Kurio. Propriedade digital para todos.
```

# Test source

```ts
  1  | import { test, expect } from "@playwright/test";
  2  | 
  3  | test("aba Aprenda abre os guias e permite filtrar conteúdos", async ({ page }) => {
  4  |   await page.goto("/aprenda");
  5  | 
  6  |   await expect(
  7  |     page.getByRole("heading", { name: /Descubra\./i }),
  8  |   ).toBeVisible();
  9  |   await expect(page.getByText("DIÁRIO DA CUNHAGEM")).toBeVisible();
  10 |   await expect(
  11 |     page.getByRole("searchbox", { name: "Buscar artigos" }),
  12 |   ).toBeVisible();
  13 | 
  14 |   await page.getByRole("button", { name: "Segurança" }).click();
  15 |   await expect(
  16 |     page.getByRole("heading", {
  17 |       name: "5 sinais de alerta para evitar golpes com NFTs",
  18 |     }),
  19 |   ).toBeVisible();
  20 |   await expect(
  21 |     page.getByRole("heading", { name: "Sua primeira carteira digital" }),
  22 |   ).toHaveCount(0);
  23 | 
  24 |   await page.getByRole("button", { name: "LER ARTIGO" }).last().click();
  25 |   await expect(
  26 |     page.getByRole("heading", {
  27 |       name: "5 sinais de alerta para evitar golpes com NFTs",
  28 |     }),
> 29 |   ).toBeVisible();
     |     ^ Error: expect(locator).toBeVisible() failed
  30 |   await expect(page.getByText("PARA LEMBRAR")).toBeVisible();
  31 | });
  32 | 
```