# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: smoke.spec.ts >> navegação mobile inclui as seções do desktop e atalhos de conta
- Location: e2e\smoke.spec.ts:876:1

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected pattern: /#criadores$/
Received string:  "http://localhost:4173/criadores"
Timeout: 5000ms

Call log:
  - Expect "toHaveURL" with timeout 5000ms
    14 × locator resolved to <html lang="pt-BR">…</html>
       - unexpected value "http://localhost:4173/criadores"

```

```yaml
- link "Ir para o conteúdo":
  - /url: "#conteudo"
- main:
  - text: PESSOAS POR TRÁS DAS OBRAS
  - heading "Conheça os criadores." [level=1]:
    - text: Conheça os
    - emphasis: criadores.
  - paragraph: Descubra os artistas e estúdios presentes nas coleções do Kurio e explore as obras que eles criaram.
  - region "Criadores para descobrir":
    - text: COMUNIDADE KURIO
    - heading "Criadores para descobrir" [level=2]
    - text: 5 criadores Buscar criador
    - searchbox "Buscar criador"
    - text: Categoria das obras
    - combobox "Filtrar criadores por categoria":
      - option "Todas as categorias" [selected]
      - option "Arte digital"
      - option "Fotografia"
      - option "Música"
      - option "Arte 3D"
      - option "Colecionáveis"
      - option "Generativa"
      - option "Jogos"
      - option "Assinaturas"
      - option "Utilidade"
    - text: Rede blockchain
    - combobox "Filtrar criadores por rede blockchain":
      - option "Todas as redes" [selected]
      - option "Ethereum"
      - option "Polygon"
      - option "Solana"
    - text: Coleção
    - combobox "Filtrar criadores por coleção":
      - option "Todas as coleções" [selected]
      - option "Digital Nomads"
      - option "Dreamscape"
      - option "Future Relics"
      - option "KURIO Genesis"
      - option "Neon Society"
    - text: Ordenar por
    - combobox "Ordenar criadores":
      - option "Mais recentes" [selected]
      - option "Mais obras"
      - option "Nome (A-Z)"
    - status: 5 criadores encontrados
    - link "Ver criador neoarchive, 48 obras em 1 coleções":
      - /url: /criadores/neoarchive
      - text: 48 obras CRIADOR KURIO
      - heading "neoarchive" [level=3]
      - paragraph: 1 coleção · Utilidade · Assinaturas
      - text: Explorar obras
    - link "Ver criador pixelmancer, 48 obras em 1 coleções":
      - /url: /criadores/pixelmancer
      - text: 48 obras CRIADOR KURIO
      - heading "pixelmancer" [level=3]
      - paragraph: 1 coleção · Utilidade · Assinaturas
      - text: Explorar obras
    - link "Ver criador rafael.art, 48 obras em 1 coleções":
      - /url: /criadores/rafael.art
      - text: 48 obras CRIADOR KURIO
      - heading "rafael.art" [level=3]
      - paragraph: 1 coleção · Utilidade · Assinaturas
      - text: Explorar obras
    - link "Ver criador studio.kurio, 48 obras em 1 coleções":
      - /url: /criadores/studio.kurio
      - text: 48 obras CRIADOR KURIO
      - heading "studio.kurio" [level=3]
      - paragraph: 1 coleção · Utilidade · Assinaturas
      - text: Explorar obras
    - link "Ver criador dreamfoundry, 47 obras em 1 coleções":
      - /url: /criadores/dreamfoundry
      - text: 47 obras CRIADOR KURIO
      - heading "dreamfoundry" [level=3]
      - paragraph: 1 coleção · Utilidade · Assinaturas
      - text: Explorar obras
- navigation "Navegação mobile":
  - link "Início":
    - /url: /
  - link "Mercado":
    - /url: /mercado
  - link "Criadores":
    - /url: /criadores
  - link "Aprenda":
    - /url: /aprenda
  - link "Carrinho de compras":
    - /url: /carrinho
    - text: Carrinho
  - link "Entrar":
    - /url: /login
    - text: Perfil
- contentinfo:
  - article:
    - text: W
    - heading "Segurança da carteira" [level=3]
    - paragraph: Proteja sua carteira e colecione arte digital verificada com confiança.
  - article:
    - text: C
    - heading "Criadores em destaque" [level=3]
    - paragraph: Conheça artistas, estúdios e comunidades que moldam a cultura digital na rede.
  - article:
    - text: D
    - heading "Alertas de lançamentos" [level=3]
    - paragraph: Receba calendários de cunhagem, novidades de listas de acesso e análises do mercado.
  - strong: KURIO
  - text: Feito para colecionadores, criadores e cultura contato@email.com +55 11 4002 8922
  - heading "Meu perfil" [level=3]
  - link "Meu perfil":
    - /url: /perfil
  - link "Carteiras":
    - /url: /carteiras
  - heading "Mercado" [level=3]
  - link "Início":
    - /url: /
  - link "Explorar NFTs":
    - /url: /#catalogo
  - link "Criadores":
    - /url: /criadores
  - heading "Coleções" [level=3]
  - link "Arte digital":
    - /url: /?categoria=%5B%22arte-digital%22%5D&pagina=1
  - link "Fotografia":
    - /url: /?categoria=%5B%22fotografia%22%5D&pagina=1
  - link "Música":
    - /url: /?categoria=%5B%22musica%22%5D&pagina=1
  - link "Arte 3D":
    - /url: /?categoria=%5B%22arte-3d%22%5D&pagina=1
  - link "Colecionáveis":
    - /url: /?categoria=%5B%22colecionaveis%22%5D&pagina=1
  - link "Generativa":
    - /url: /?categoria=%5B%22generativa%22%5D&pagina=1
  - link "Jogos":
    - /url: /?categoria=%5B%22jogos%22%5D&pagina=1
  - link "Assinaturas":
    - /url: /?categoria=%5B%22assinaturas%22%5D&pagina=1
  - link "Utilidade":
    - /url: /?categoria=%5B%22utilidade%22%5D&pagina=1
  - heading "Carteiras compatíveis" [level=3]
  - text: METAMASK â€¢WALLETCONNECT â€¢COINBASE © 2026 Kurio. Propriedade digital para todos.
```

# Test source

```ts
  808 |     5,
  809 |   );
  810 |   await expect(profileSidebar.locator('a[href^="#"]')).toHaveCount(0);
  811 |   const profileMenuText = await profileSidebar.innerText();
  812 | 
  813 |   await page.goto("/carteiras");
  814 |   const walletsSidebar = page.locator(".account-sidebar");
  815 |   await expect(
  816 |     walletsSidebar.getByRole("link", { name: "Carteiras" }),
  817 |   ).toHaveAttribute("aria-current", "page");
  818 |   await expect(walletsSidebar.innerText()).resolves.toBe(profileMenuText);
  819 |   await expect(walletsSidebar.locator(".account-sidebar-disabled")).toHaveCount(
  820 |     5,
  821 |   );
  822 |   await expect(walletsSidebar.locator('a[href^="#"]')).toHaveCount(0);
  823 | });
  824 | 
  825 | test("avatar do perfil é persistido após refresh", async ({ page }) => {
  826 |   await login(page);
  827 |   await page.goto("/perfil");
  828 |   await page.getByLabel("Apelido da carteira").fill("avatar-test");
  829 |   await page
  830 |     .getByLabel("Enviar imagem de perfil")
  831 |     .setInputFiles(resolve("public/nfts/NFT Artwork 03.png"));
  832 |   await expect(page.locator(".avatar-placeholder img")).toHaveAttribute(
  833 |     "src",
  834 |     /^data:image\/jpeg/,
  835 |   );
  836 |   await page.getByRole("button", { name: "Salvar", exact: true }).click();
  837 |   await expect(page.getByRole("status")).toContainText(
  838 |     "Dados do perfil salvos",
  839 |   );
  840 |   await page.reload();
  841 |   await expect(page.locator(".avatar-placeholder img")).toHaveAttribute(
  842 |     "src",
  843 |     /^data:image\/jpeg/,
  844 |   );
  845 | });
  846 | 
  847 | test("telas da etapa 1 não transbordam nos três breakpoints", async ({
  848 |   page,
  849 | }) => {
  850 |   await login(page);
  851 |   const routes = [
  852 |     ["/", ".hero"],
  853 |     ["/nfts/nft-002", ".nft-detail-main"],
  854 |     ["/perfil", ".avatar-field"],
  855 |     ["/carteiras", ".wallet-title"],
  856 |     ["/login", ".auth-modal"],
  857 |     ["/cadastro", ".register-modal"],
  858 |   ];
  859 | 
  860 |   for (const width of [390, 768, 1440]) {
  861 |     await page.setViewportSize({ width, height: 1000 });
  862 |     for (const [path, selector] of routes) {
  863 |       await page.goto(path);
  864 |       await expect(page.locator(selector)).toBeVisible();
  865 |       await expect
  866 |         .poll(() =>
  867 |           page.evaluate(
  868 |             () => document.documentElement.scrollWidth <= window.innerWidth,
  869 |           ),
  870 |         )
  871 |         .toBe(true);
  872 |     }
  873 |   }
  874 | });
  875 | 
  876 | test("navegação mobile inclui as seções do desktop e atalhos de conta", async ({
  877 |   page,
  878 | }, testInfo) => {
  879 |   test.skip(
  880 |     testInfo.project.name !== "mobile",
  881 |     "A barra inferior só é exibida no viewport mobile.",
  882 |   );
  883 |   await page.goto("/");
  884 |   const mobileNav = page.getByRole("navigation", {
  885 |     name: "Navegação mobile",
  886 |   });
  887 |   await expect(mobileNav).toBeVisible();
  888 |   for (const label of [
  889 |     "Início",
  890 |     "Mercado",
  891 |     "Criadores",
  892 |     "Aprenda",
  893 |   ]) {
  894 |     await expect(mobileNav.getByRole("link", { name: label })).toBeVisible();
  895 |   }
  896 |   await expect(
  897 |     mobileNav.getByRole("link", { name: "Carrinho de compras" }),
  898 |   ).toBeVisible();
  899 |   await expect(
  900 |     mobileNav.getByRole("link", { name: /perfil|entrar/i }),
  901 |   ).toBeVisible();
  902 |   await mobileNav.getByRole("link", { name: "Mercado" }).click();
  903 |   await expect(page).toHaveURL(/\/mercado$/);
  904 |   await expect(
  905 |     page.getByRole("heading", { name: "Explore o universo digital." }),
  906 |   ).toBeVisible();
  907 |   await mobileNav.getByRole("link", { name: "Criadores" }).click();
> 908 |   await expect(page).toHaveURL(/#criadores$/);
      |                      ^ Error: expect(page).toHaveURL(expected) failed
  909 |   await mobileNav.getByRole("link", { name: "Aprenda" }).click();
  910 |   await expect(page).toHaveURL(/#aprenda$/);
  911 |   await login(page);
  912 |   await mobileNav.getByRole("link", { name: "Perfil" }).click();
  913 |   await expect(page).toHaveURL(/\/perfil$/);
  914 |   await expect(page.locator(".site-header")).toBeHidden();
  915 |   await expect(page.locator(".app-root")).toHaveClass(/app-account/);
  916 |   await expect(
  917 |     mobileNav.getByRole("link", { name: "Perfil" }),
  918 |   ).toHaveAttribute("aria-current", "page");
  919 | });
  920 | 
  921 |   test('Roboto local é carregada na aplicação', async ({ page }) => {
  922 |     await page.goto('/');
  923 |     const loadedFamilies = await page.evaluate(async () =>
  924 |       (await document.fonts.load('16px Roboto')).map((font) => font.family),
  925 |     );
  926 |     expect(loadedFamilies).toContain('Roboto');
  927 |   });
  928 | 
  929 | test("diálogo de login controla foco, Tab e Escape", async ({ page }) => {
  930 |   await page.goto("/login");
  931 |   const dialog = page.getByRole("dialog", { name: "Entrar" });
  932 |   await expect(dialog).toBeVisible();
  933 |   await expect(dialog.getByLabel("E-mail", { exact: true })).toBeFocused();
  934 |   await dialog.getByRole("button", { name: "Fechar login" }).focus();
  935 |   await page.keyboard.press("Shift+Tab");
  936 |   await expect(
  937 |     dialog.getByRole("button", { name: "Continuar com Facebook" }),
  938 |   ).toBeFocused();
  939 |   await page.keyboard.press("Escape");
  940 |   await expect(page).toHaveURL(/\/\?/);
  941 | });
  942 | 
  943 | test("skeleton do catálogo aparece durante rede lenta e some ao concluir", async ({
  944 |   page,
  945 | }) => {
  946 |   await page.goto("/?mockScenario=slow-network");
  947 |   await expect(page.locator(".nft-skeleton").first()).toBeVisible();
  948 |   await expect(page.locator(".nft-skeleton")).toHaveCount(0, {
  949 |     timeout: 5_000,
  950 |   });
  951 |   await expect(page.locator(".nft-card").first()).toBeVisible();
  952 | });
  953 | 
  954 | test("drawer de filtros no mobile controla foco e fecha com Escape", async ({
  955 |   page,
  956 | }, testInfo) => {
  957 |   test.skip(
  958 |     testInfo.project.name !== "mobile",
  959 |     "O drawer só é exibido no viewport mobile.",
  960 |   );
  961 |   await page.goto("/");
  962 |   await page.getByRole("button", { name: /FILTROS/i }).click();
  963 |   await expect(
  964 |     page.getByRole("dialog", { name: "Filtros de obras" }),
  965 |   ).toBeVisible();
  966 |   await expect(page.getByRole("button", { name: "LIMPAR TUDO" })).toBeFocused();
  967 |   await page.keyboard.press("Escape");
  968 |   await expect(
  969 |     page.getByRole("dialog", { name: "Filtros de obras" }),
  970 |   ).toHaveCount(0);
  971 | });
  972 | 
```