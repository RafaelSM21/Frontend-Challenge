# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: smoke.spec.ts >> lateral de conta é igual em perfil e carteiras
- Location: e2e\smoke.spec.ts:800:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.account-sidebar').locator('.account-sidebar-disabled')
Expected: 5
Received: 0
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('.account-sidebar').locator('.account-sidebar-disabled') with timeout 5000ms
  - waiting for locator('.account-sidebar').locator('.account-sidebar-disabled')
    14 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [ref=f4e3]:
  - link "Ir para o conteúdo" [ref=f4e4] [cursor=pointer]:
    - /url: "#conteudo"
  - banner [ref=f4e5]:
    - navigation "Principal" [ref=f4e6]:
      - link "Kurio, página inicial" [ref=f4e7] [cursor=pointer]:
        - /url: /
        - generic [ref=f4e8]: KURIO
      - generic [ref=f4e9]:
        - link "Início" [ref=f4e10] [cursor=pointer]:
          - /url: /
        - link "Mercado" [ref=f4e11] [cursor=pointer]:
          - /url: /mercado
        - link "Criadores" [ref=f4e12] [cursor=pointer]:
          - /url: /criadores
        - link "Aprenda" [ref=f4e13] [cursor=pointer]:
          - /url: /aprenda
      - generic [ref=f4e14]:
        - button "Buscar obras" [ref=f4e16] [cursor=pointer]
        - link "Carrinho de compras, 0 itens" [ref=f4e18] [cursor=pointer]:
          - /url: /carrinho
          - generic [ref=f4e20]: "0"
        - generic [ref=f4e21]:
          - link "Abrir meu perfil" [ref=f4e22] [cursor=pointer]:
            - /url: /perfil
          - button "Sair" [ref=f4e24] [cursor=pointer]
  - main [ref=f4e25]:
    - generic [ref=f4e26]:
      - complementary [ref=f4e27]:
        - heading "Meu perfil" [level=1] [ref=f4e28]
        - link "Dados do perfil" [ref=f4e29] [cursor=pointer]:
          - /url: /perfil
        - link "Carteiras" [ref=f4e33] [cursor=pointer]:
          - /url: /carteiras
        - link "Atividade" [ref=f4e37] [cursor=pointer]:
          - /url: /atividade
        - link "Lista de interesse" [ref=f4e43] [cursor=pointer]:
          - /url: /interesse
        - link "Ofertas" [ref=f4e46] [cursor=pointer]:
          - /url: /ofertas
        - link "Arquivos baixados" [ref=f4e50] [cursor=pointer]:
          - /url: /downloads
        - link "Suporte" [ref=f4e54] [cursor=pointer]:
          - /url: /suporte
        - button "Sair" [ref=f4e57] [cursor=pointer]
      - generic [ref=f4e61]:
        - heading "Perfil do colecionador" [level=2] [ref=f4e62]
        - generic [ref=f4e63]:
          - generic [ref=f4e64]:
            - generic [ref=f4e65]:
              - text: Nome de exibição
              - textbox "Nome de exibição" [ref=f4e66]: Rafael Soares
            - generic [ref=f4e67]:
              - generic [ref=f4e68]: Foto de perfil
              - generic [ref=f4e69]:
                - generic [ref=f4e70]: R
                - generic [ref=f4e71] [cursor=pointer]:
                  - text: Enviar imagem
                  - button "Enviar imagem de perfil" [ref=f4e72]
              - generic [ref=f4e73]: Se seu nome de usuário corresponder ao identificador de um criador, esta foto também será exibida no perfil público dele.
            - generic [ref=f4e74]:
              - text: Nome de usuário
              - textbox "Nome de usuário" [ref=f4e75]: rafael
            - generic [ref=f4e76]:
              - text: E-mail
              - textbox "E-mail" [ref=f4e77]: rafael@example.com
            - generic [ref=f4e78]:
              - text: Nome ENS
              - textbox "Nome ENS" [ref=f4e79]
            - generic [ref=f4e80]:
              - text: Apelido da carteira
              - textbox "Apelido da carteira" [ref=f4e81]
          - heading "Alterar senha" [level=3] [ref=f4e82]
          - generic [ref=f4e83]:
            - generic [ref=f4e84]:
              - text: Senha atual
              - textbox "Senha atual" [ref=f4e85]
            - generic [ref=f4e86]:
              - text: Nova senha
              - textbox "Nova senha" [ref=f4e87]
            - generic [ref=f4e88]:
              - text: Confirmar nova senha
              - textbox "Confirmar nova senha" [ref=f4e89]
          - button "Salvar" [ref=f4e90] [cursor=pointer]
  - contentinfo [ref=f4e91]:
    - generic [ref=f4e92]:
      - article [ref=f4e93]:
        - generic [ref=f4e94]: W
        - heading "Segurança da carteira" [level=3] [ref=f4e95]
        - paragraph [ref=f4e96]: Proteja sua carteira e colecione arte digital verificada com confiança.
      - article [ref=f4e97]:
        - generic [ref=f4e98]: C
        - heading "Criadores em destaque" [level=3] [ref=f4e99]
        - paragraph [ref=f4e100]: Conheça artistas, estúdios e comunidades que moldam a cultura digital na rede.
      - article [ref=f4e101]:
        - generic [ref=f4e102]: D
        - heading "Alertas de lançamentos" [level=3] [ref=f4e103]
        - paragraph [ref=f4e104]: Receba calendários de cunhagem, novidades de listas de acesso e análises do mercado.
    - generic [ref=f4e105]:
      - strong [ref=f4e106]: KURIO
      - generic [ref=f4e107]: Feito para colecionadores,criadores e cultura
      - generic [ref=f4e108]: contato@email.com
      - generic [ref=f4e109]: +55 11 4002 8922
    - generic [ref=f4e110]:
      - generic [ref=f4e111]:
        - heading "Meu perfil" [level=3] [ref=f4e112]
        - link "Meu perfil" [ref=f4e113] [cursor=pointer]:
          - /url: /perfil
        - link "Carteiras" [ref=f4e114] [cursor=pointer]:
          - /url: /carteiras
      - generic [ref=f4e115]:
        - heading "Mercado" [level=3] [ref=f4e116]
        - link "Início" [ref=f4e117] [cursor=pointer]:
          - /url: /
        - link "Explorar NFTs" [ref=f4e118] [cursor=pointer]:
          - /url: /#catalogo
        - link "Criadores" [ref=f4e119] [cursor=pointer]:
          - /url: /criadores
      - generic [ref=f4e120]:
        - heading "Coleções" [level=3] [ref=f4e121]
        - link "Arte digital" [ref=f4e122] [cursor=pointer]:
          - /url: /?categoria=%5B%22arte-digital%22%5D&pagina=1
        - link "Fotografia" [ref=f4e123] [cursor=pointer]:
          - /url: /?categoria=%5B%22fotografia%22%5D&pagina=1
        - link "Música" [ref=f4e124] [cursor=pointer]:
          - /url: /?categoria=%5B%22musica%22%5D&pagina=1
        - link "Arte 3D" [ref=f4e125] [cursor=pointer]:
          - /url: /?categoria=%5B%22arte-3d%22%5D&pagina=1
        - link "Colecionáveis" [ref=f4e126] [cursor=pointer]:
          - /url: /?categoria=%5B%22colecionaveis%22%5D&pagina=1
        - link "Generativa" [ref=f4e127] [cursor=pointer]:
          - /url: /?categoria=%5B%22generativa%22%5D&pagina=1
        - link "Jogos" [ref=f4e128] [cursor=pointer]:
          - /url: /?categoria=%5B%22jogos%22%5D&pagina=1
        - link "Assinaturas" [ref=f4e129] [cursor=pointer]:
          - /url: /?categoria=%5B%22assinaturas%22%5D&pagina=1
        - link "Utilidade" [ref=f4e130] [cursor=pointer]:
          - /url: /?categoria=%5B%22utilidade%22%5D&pagina=1
      - generic [ref=f4e131]:
        - heading "Carteiras compatíveis" [level=3] [ref=f4e132]
        - generic [ref=f4e133]:
          - generic [ref=f4e134]: METAMASK
          - generic [ref=f4e135]: â€¢WALLETCONNECT
          - generic [ref=f4e136]: â€¢COINBASE
    - generic [ref=f4e137]: © 2026 Kurio. Propriedade digital para todos.
```

# Test source

```ts
  707 |   expect(updatedWhileDisconnected).toBe(true);
  708 |   await page.waitForFunction(
  709 |     () =>
  710 |       Boolean(
  711 |         (window as Window & { __kurioSocketConnected?: boolean })
  712 |           .__kurioSocketConnected,
  713 |       ),
  714 |     { timeout: 10_000 },
  715 |   );
  716 |   await expect(page.getByText("COMPRA CONFIRMADA")).toBeVisible();
  717 | });
  718 | 
  719 | test("conflito de estoque durante a compra mantém o carrinho", async ({
  720 |   page,
  721 | }) => {
  722 |   await loginAndAddNft(page);
  723 |   await page.goto("/pagamento?mockScenario=stock-conflict");
  724 |   await page.getByRole("button", { name: /confirmar compra/i }).click();
  725 |   await expect(page.getByRole("alert")).toContainText("esgotou");
  726 |   await page.goto("/carrinho");
  727 |   await expect(
  728 |     page.getByRole("heading", { name: /Astronaut #002/i }),
  729 |   ).toBeVisible();
  730 | });
  731 | 
  732 | test("cadastro valida confirmação de senha e sessão expirada retorna ao login", async ({
  733 |   page,
  734 | }) => {
  735 |   await page.goto("/cadastro");
  736 |   const dialog = page.getByRole("dialog", { name: "Criar conta" });
  737 |   await dialog.locator("#register-name").fill("Novo colecionador");
  738 |   await dialog.locator("#register-email").fill("novo@example.com");
  739 |   await dialog.locator("#register-password").fill("SenhaSegura1!");
  740 |   const confirmation = dialog.locator("#register-confirm");
  741 |   await confirmation.fill("SenhaDiferente1!");
  742 |   await expect(confirmation).toHaveValue("SenhaDiferente1!");
  743 |   await confirmation.press("Enter");
  744 |   await expect(dialog.getByRole("alert")).toContainText("não coincidem");
  745 |   await login(page);
  746 |   await page.goto("/carrinho?mockScenario=session-expired");
  747 |   await page.waitForURL("**/login");
  748 | });
  749 | 
  750 | test("favorito faz rollback e informa falha da mutation", async ({ page }) => {
  751 |   await login(page);
  752 |   await page.goto("/nfts/nft-002?mockScenario=favorite-failure");
  753 |   const favorite = page
  754 |     .getByRole("button", { name: "Adicionar aos favoritos" })
  755 |     .first();
  756 |   await favorite.click();
  757 |   await expect(page.getByRole("alert")).toContainText(
  758 |     "Não foi possível atualizar os favoritos",
  759 |   );
  760 |   await expect(
  761 |     page.getByRole("button", { name: "Adicionar aos favoritos" }).first(),
  762 |   ).toBeVisible();
  763 | });
  764 | 
  765 | test("carrinho trata cupom expirado, quantidade e remoção", async ({
  766 |   page,
  767 | }) => {
  768 |   await login(page);
  769 |   await page.goto("/nfts/nft-002");
  770 |   await page.getByRole("button", { name: /comprar/i }).click();
  771 |   await page.getByLabel("Aumentar Astronaut #002").click();
  772 |   await expect(page.getByText("2", { exact: true }).last()).toBeVisible();
  773 |   await page.getByLabel("Cupom de desconto").fill("EXPIRADO");
  774 |   await page.getByRole("button", { name: "Aplicar" }).click();
  775 |   await expect(page.getByRole("alert")).toContainText("expirou");
  776 |   await page.getByRole("button", { name: "Remover" }).click();
  777 |   await expect(page.getByText("Seu carrinho está vazio.")).toBeVisible();
  778 | });
  779 | 
  780 | test("perfil salva alterações e valida senha pela API", async ({ page }) => {
  781 |   await login(page);
  782 |   await page.goto("/perfil");
  783 |   await page.getByLabel("Nome de exibição").fill("Rafael Atualizado");
  784 |   await page.getByLabel("Apelido da carteira").fill("carteira-rafael");
  785 |   await page.getByRole("button", { name: "Salvar" }).click();
  786 |   await expect(page.getByRole("status")).toContainText(
  787 |     "Dados do perfil salvos",
  788 |   );
  789 |   await page.getByLabel("Senha atual").fill("senha-incorreta");
  790 |   await page.getByLabel("Nova senha", { exact: true }).fill("SenhaNova123!");
  791 |   await page
  792 |     .getByLabel("Confirmar nova senha", { exact: true })
  793 |     .fill("SenhaNova123!");
  794 |   await page.getByRole("button", { name: "Salvar" }).click();
  795 |   await expect(page.getByRole("status")).toContainText(
  796 |     "senha atual está incorreta",
  797 |   );
  798 | });
  799 | 
  800 | test("lateral de conta é igual em perfil e carteiras", async ({ page }) => {
  801 |   await login(page);
  802 |   await page.goto("/perfil");
  803 |   const profileSidebar = page.locator(".account-sidebar");
  804 |   await expect(
  805 |     profileSidebar.getByRole("link", { name: "Dados do perfil" }),
  806 |   ).toHaveAttribute("aria-current", "page");
> 807 |   await expect(profileSidebar.locator(".account-sidebar-disabled")).toHaveCount(
      |                                                                     ^ Error: expect(locator).toHaveCount(expected) failed
  808 |     5,
  809 |   );
  810 |   await expect(profileSidebar.locator('a[href^="#"]')).toHaveCount(0);
  811 |   const profileMenuText = await profileSidebar.innerText();
  812 | 
  813 |   await page.goto("/carteiras");
  814 |   const walletsSidebar = page.locator(".account-sidebar");
  815 |   await expect(
  816 |     walletsSidebar.getByRole("link", { name: "Carteiras" }),
  817 |   ).toHaveAttribute("aria-current", "page");
  818 |   await expect(walletsSidebar.innerText()).resolves.toBe(profileMenuText);
  819 |   await expect(walletsSidebar.locator(".account-sidebar-disabled")).toHaveCount(
  820 |     5,
  821 |   );
  822 |   await expect(walletsSidebar.locator('a[href^="#"]')).toHaveCount(0);
  823 | });
  824 | 
  825 | test("avatar do perfil é persistido após refresh", async ({ page }) => {
  826 |   await login(page);
  827 |   await page.goto("/perfil");
  828 |   await page.getByLabel("Apelido da carteira").fill("avatar-test");
  829 |   await page
  830 |     .getByLabel("Enviar imagem de perfil")
  831 |     .setInputFiles(resolve("public/nfts/NFT Artwork 03.png"));
  832 |   await expect(page.locator(".avatar-placeholder img")).toHaveAttribute(
  833 |     "src",
  834 |     /^data:image\/jpeg/,
  835 |   );
  836 |   await page.getByRole("button", { name: "Salvar", exact: true }).click();
  837 |   await expect(page.getByRole("status")).toContainText(
  838 |     "Dados do perfil salvos",
  839 |   );
  840 |   await page.reload();
  841 |   await expect(page.locator(".avatar-placeholder img")).toHaveAttribute(
  842 |     "src",
  843 |     /^data:image\/jpeg/,
  844 |   );
  845 | });
  846 | 
  847 | test("telas da etapa 1 não transbordam nos três breakpoints", async ({
  848 |   page,
  849 | }) => {
  850 |   await login(page);
  851 |   const routes = [
  852 |     ["/", ".hero"],
  853 |     ["/nfts/nft-002", ".nft-detail-main"],
  854 |     ["/perfil", ".avatar-field"],
  855 |     ["/carteiras", ".wallet-title"],
  856 |     ["/login", ".auth-modal"],
  857 |     ["/cadastro", ".register-modal"],
  858 |   ];
  859 | 
  860 |   for (const width of [390, 768, 1440]) {
  861 |     await page.setViewportSize({ width, height: 1000 });
  862 |     for (const [path, selector] of routes) {
  863 |       await page.goto(path);
  864 |       await expect(page.locator(selector)).toBeVisible();
  865 |       await expect
  866 |         .poll(() =>
  867 |           page.evaluate(
  868 |             () => document.documentElement.scrollWidth <= window.innerWidth,
  869 |           ),
  870 |         )
  871 |         .toBe(true);
  872 |     }
  873 |   }
  874 | });
  875 | 
  876 | test("navegação mobile inclui as seções do desktop e atalhos de conta", async ({
  877 |   page,
  878 | }, testInfo) => {
  879 |   test.skip(
  880 |     testInfo.project.name !== "mobile",
  881 |     "A barra inferior só é exibida no viewport mobile.",
  882 |   );
  883 |   await page.goto("/");
  884 |   const mobileNav = page.getByRole("navigation", {
  885 |     name: "Navegação mobile",
  886 |   });
  887 |   await expect(mobileNav).toBeVisible();
  888 |   for (const label of [
  889 |     "Início",
  890 |     "Mercado",
  891 |     "Criadores",
  892 |     "Aprenda",
  893 |   ]) {
  894 |     await expect(mobileNav.getByRole("link", { name: label })).toBeVisible();
  895 |   }
  896 |   await expect(
  897 |     mobileNav.getByRole("link", { name: "Carrinho de compras" }),
  898 |   ).toBeVisible();
  899 |   await expect(
  900 |     mobileNav.getByRole("link", { name: /perfil|entrar/i }),
  901 |   ).toBeVisible();
  902 |   await mobileNav.getByRole("link", { name: "Mercado" }).click();
  903 |   await expect(page).toHaveURL(/\/mercado$/);
  904 |   await expect(
  905 |     page.getByRole("heading", { name: "Explore o universo digital." }),
  906 |   ).toBeVisible();
  907 |   await mobileNav.getByRole("link", { name: "Criadores" }).click();
```