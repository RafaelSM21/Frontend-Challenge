# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: smoke.spec.ts >> Mercado explora coleções e conecta ao catálogo filtrado
- Location: e2e\smoke.spec.ts:112:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.fill: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('searchbox', { name: 'Buscar coleções ou criadores' })

```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - link "Ir para o conteúdo" [ref=f2e4] [cursor=pointer]:
    - /url: "#conteudo"
  - banner [ref=f2e5]:
    - navigation "Principal" [ref=f2e6]:
      - link "Kurio, página inicial" [ref=f2e7] [cursor=pointer]:
        - /url: /
        - generic [ref=f2e8]: KURIO
      - generic [ref=f2e9]:
        - link "Início" [ref=f2e10] [cursor=pointer]:
          - /url: /
        - link "Mercado" [ref=f2e11] [cursor=pointer]:
          - /url: /mercado
        - link "Criadores" [ref=f2e12] [cursor=pointer]:
          - /url: /criadores
        - link "Aprenda" [ref=f2e13] [cursor=pointer]:
          - /url: /aprenda
      - generic [ref=f2e14]:
        - button "Buscar obras" [ref=f2e16] [cursor=pointer]
        - link "Carrinho de compras, 0 itens" [ref=f2e18] [cursor=pointer]:
          - /url: /carrinho
          - generic [ref=f2e20]: "0"
        - link "Entrar" [ref=f2e21] [cursor=pointer]:
          - /url: /login
  - main [ref=f2e22]:
    - generic [ref=f2e23]:
      - generic [ref=f2e24]:
        - generic [ref=f2e25]: CURADORIA KURIO
        - heading [level=1] [ref=f2e27]:
          - text: Explore o universo
          - emphasis [ref=f2e28]: digital.
        - paragraph [ref=f2e29]: Descubra coleções, conheça seus criadores e encontre a próxima obra para sua coleção.
      - region [ref=f2e30]:
        - generic [ref=f2e31]:
          - generic [ref=f2e32]:
            - generic [ref=f2e33]: DESCUBRA ALGO NOVO
            - heading "Coleções para explorar" [level=2] [ref=f2e35]
          - generic [ref=f2e36]: 5 coleções
        - generic "Filtros de coleções" [ref=f2e37]:
          - generic [ref=f2e38]:
            - generic [ref=f2e39]: Categoria
            - combobox "Filtrar por categoria" [ref=f2e40]:
              - option "Todas as categorias" [selected]
              - option "Arte digital"
              - option "Fotografia"
              - option "Música"
              - option "Arte 3D"
              - option "Colecionáveis"
              - option "Generativa"
              - option "Jogos"
              - option "Assinaturas"
              - option "Utilidade"
          - generic [ref=f2e41]:
            - generic [ref=f2e42]: Rede
            - combobox "Filtrar por rede" [ref=f2e43]:
              - option "Todas as redes" [selected]
              - option "Ethereum"
              - option "Polygon"
              - option "Solana"
          - generic [ref=f2e44]:
            - generic [ref=f2e45]: Criador
            - combobox "Filtrar por criador" [ref=f2e46]:
              - option "Todos os criadores" [selected]
              - option "dreamfoundry"
              - option "neoarchive"
              - option "pixelmancer"
              - option "rafael.art"
              - option "studio.kurio"
          - generic [ref=f2e47]:
            - generic [ref=f2e48]: Ordenar
            - combobox "Ordenar coleções" [ref=f2e49]:
              - option "Mais recentes" [selected]
              - option "Mais NFTs"
              - option "Nome (A–Z)"
        - status [ref=f2e50]: 5 coleções encontradas
        - generic [ref=f2e51]:
          - link "Explorar coleção Dreamscape, 48 NFTs, por neoarchive" [ref=f2e52] [cursor=pointer]:
            - /url: /colecoes/Dreamscape
            - generic [ref=f2e54]: 48 NFTs
            - generic [ref=f2e59]:
              - generic [ref=f2e60]: Utilidade · Assinaturas
              - heading "Dreamscape" [level=3] [ref=f2e61]
              - paragraph [ref=f2e62]: por neoarchive
              - paragraph [ref=f2e63]: 9 estilos artísticos em uma coleção para explorar.
              - generic [ref=f2e64]: Explorar coleção
          - link "Explorar coleção Neon Society, 48 NFTs, por pixelmancer" [ref=f2e69] [cursor=pointer]:
            - /url: /colecoes/Neon%20Society
            - generic [ref=f2e71]: 48 NFTs
            - generic [ref=f2e76]:
              - generic [ref=f2e77]: Utilidade · Assinaturas
              - heading "Neon Society" [level=3] [ref=f2e78]
              - paragraph [ref=f2e79]: por pixelmancer
              - paragraph [ref=f2e80]: 9 estilos artísticos em uma coleção para explorar.
              - generic [ref=f2e81]: Explorar coleção
          - link "Explorar coleção Digital Nomads, 48 NFTs, por rafael.art" [ref=f2e86] [cursor=pointer]:
            - /url: /colecoes/Digital%20Nomads
            - generic [ref=f2e88]: 48 NFTs
            - generic [ref=f2e93]:
              - generic [ref=f2e94]: Utilidade · Assinaturas
              - heading "Digital Nomads" [level=3] [ref=f2e95]
              - paragraph [ref=f2e96]: por rafael.art
              - paragraph [ref=f2e97]: 9 estilos artísticos em uma coleção para explorar.
              - generic [ref=f2e98]: Explorar coleção
          - link "Explorar coleção KURIO Genesis, 48 NFTs, por studio.kurio" [ref=f2e103] [cursor=pointer]:
            - /url: /colecoes/KURIO%20Genesis
            - generic [ref=f2e105]: 48 NFTs
            - generic [ref=f2e110]:
              - generic [ref=f2e111]: Utilidade · Assinaturas
              - heading "KURIO Genesis" [level=3] [ref=f2e112]
              - paragraph [ref=f2e113]: por studio.kurio
              - paragraph [ref=f2e114]: 9 estilos artísticos em uma coleção para explorar.
              - generic [ref=f2e115]: Explorar coleção
          - link "Explorar coleção Future Relics, 47 NFTs, por dreamfoundry" [ref=f2e120] [cursor=pointer]:
            - /url: /colecoes/Future%20Relics
            - generic [ref=f2e122]: 47 NFTs
            - generic [ref=f2e127]:
              - generic [ref=f2e128]: Utilidade · Assinaturas
              - heading "Future Relics" [level=3] [ref=f2e129]
              - paragraph [ref=f2e130]: por dreamfoundry
              - paragraph [ref=f2e131]: 9 estilos artísticos em uma coleção para explorar.
              - generic [ref=f2e132]: Explorar coleção
  - contentinfo [ref=f2e137]:
    - generic [ref=f2e138]:
      - article [ref=f2e139]:
        - generic [ref=f2e140]: W
        - heading "Segurança da carteira" [level=3] [ref=f2e141]
        - paragraph [ref=f2e142]: Proteja sua carteira e colecione arte digital verificada com confiança.
      - article [ref=f2e143]:
        - generic [ref=f2e144]: C
        - heading "Criadores em destaque" [level=3] [ref=f2e145]
        - paragraph [ref=f2e146]: Conheça artistas, estúdios e comunidades que moldam a cultura digital na rede.
      - article [ref=f2e147]:
        - generic [ref=f2e148]: D
        - heading "Alertas de lançamentos" [level=3] [ref=f2e149]
        - paragraph [ref=f2e150]: Receba calendários de cunhagem, novidades de listas de acesso e análises do mercado.
    - generic [ref=f2e151]:
      - strong [ref=f2e152]: KURIO
      - generic [ref=f2e153]: Feito para colecionadores,criadores e cultura
      - generic [ref=f2e154]: contato@email.com
      - generic [ref=f2e155]: +55 11 4002 8922
    - generic [ref=f2e156]:
      - generic [ref=f2e157]:
        - heading "Meu perfil" [level=3] [ref=f2e158]
        - link "Meu perfil" [ref=f2e159] [cursor=pointer]:
          - /url: /perfil
        - link "Carteiras" [ref=f2e160] [cursor=pointer]:
          - /url: /carteiras
      - generic [ref=f2e161]:
        - heading "Mercado" [level=3] [ref=f2e162]
        - link "Início" [ref=f2e163] [cursor=pointer]:
          - /url: /
        - link "Explorar NFTs" [ref=f2e164] [cursor=pointer]:
          - /url: /#catalogo
        - link "Criadores" [ref=f2e165] [cursor=pointer]:
          - /url: /criadores
      - generic [ref=f2e166]:
        - heading "Coleções" [level=3] [ref=f2e167]
        - link "Arte digital" [ref=f2e168] [cursor=pointer]:
          - /url: /?categoria=%5B%22arte-digital%22%5D&pagina=1
        - link "Fotografia" [ref=f2e169] [cursor=pointer]:
          - /url: /?categoria=%5B%22fotografia%22%5D&pagina=1
        - link "Música" [ref=f2e170] [cursor=pointer]:
          - /url: /?categoria=%5B%22musica%22%5D&pagina=1
        - link "Arte 3D" [ref=f2e171] [cursor=pointer]:
          - /url: /?categoria=%5B%22arte-3d%22%5D&pagina=1
        - link "Colecionáveis" [ref=f2e172] [cursor=pointer]:
          - /url: /?categoria=%5B%22colecionaveis%22%5D&pagina=1
        - link "Generativa" [ref=f2e173] [cursor=pointer]:
          - /url: /?categoria=%5B%22generativa%22%5D&pagina=1
        - link "Jogos" [ref=f2e174] [cursor=pointer]:
          - /url: /?categoria=%5B%22jogos%22%5D&pagina=1
        - link "Assinaturas" [ref=f2e175] [cursor=pointer]:
          - /url: /?categoria=%5B%22assinaturas%22%5D&pagina=1
        - link "Utilidade" [ref=f2e176] [cursor=pointer]:
          - /url: /?categoria=%5B%22utilidade%22%5D&pagina=1
      - generic [ref=f2e177]:
        - heading "Carteiras compatíveis" [level=3] [ref=f2e178]
        - generic [ref=f2e179]:
          - generic [ref=f2e180]: METAMASK
          - generic [ref=f2e181]: â€¢WALLETCONNECT
          - generic [ref=f2e182]: â€¢COINBASE
    - generic [ref=f2e183]: © 2026 Kurio. Propriedade digital para todos.
```

# Test source

```ts
  26  |   // garante que cada teste começa no mesmo estado observável.
  27  |   await page.reload();
  28  | });
  29  | 
  30  | async function login(page: import("@playwright/test").Page) {
  31  |   await page.goto("/login");
  32  |   const dialog = page.getByRole("dialog", { name: "Entrar" });
  33  |   await dialog.locator("#login-email").fill("rafael@example.com");
  34  |   await dialog.locator("#login-password").fill("Kurio123!");
  35  |   await dialog.getByRole("button", { name: "Entrar" }).click();
  36  |   await expect
  37  |     .poll(() =>
  38  |       page.evaluate(() => Boolean(localStorage.getItem("kurio.session"))),
  39  |     )
  40  |     .toBe(true);
  41  |   await page.goto("/");
  42  |   if ((page.viewportSize()?.width ?? Infinity) <= 720) {
  43  |     await expect(
  44  |       page
  45  |         .getByRole("navigation", { name: "Navegação mobile" })
  46  |         .getByRole("link", { name: "Perfil" }),
  47  |     ).toBeVisible();
  48  |   } else {
  49  |     await expect(page.getByLabel("Abrir meu perfil")).toBeVisible();
  50  |   }
  51  | }
  52  | 
  53  | async function createWallet(page: import("@playwright/test").Page) {
  54  |   await page.goto("/carteiras");
  55  |   await page.getByLabel(/Nome de exibição/i).fill("Carteira de checkout");
  56  |   await page.getByLabel(/Apelido da carteira/i).fill("checkout");
  57  |   await page.getByLabel("Nome do perfil").fill("Rafael");
  58  |   await page.getByLabel(/Endereço da carteira/i).fill("0x1234567890abcdef");
  59  |   await page.getByRole("button", { name: "Salvar carteira" }).click();
  60  |   await expect(page.getByText("Carteira salva na sua conta.")).toBeVisible();
  61  | }
  62  | 
  63  | async function selectAndConnectWallet(page: import("@playwright/test").Page) {
  64  |   await page.getByLabel("Carteira cadastrada").selectOption({ index: 1 });
  65  |   await page.getByRole("button", { name: "CONECTAR CARTEIRA" }).click();
  66  |   await expect(
  67  |     page.getByText("Carteira conectada para esta compra."),
  68  |   ).toBeVisible();
  69  | }
  70  | 
  71  | test("catálogo responde a filtros e acesso direto ao detalhe", async ({
  72  |   page,
  73  | }) => {
  74  |   await page.goto("/?q=Ape%20%23001");
  75  |   await expect(
  76  |     page.getByRole("heading", { name: /SEJA DONO DO FUTURO/i }),
  77  |   ).toBeVisible();
  78  |   await expect(
  79  |     page.locator(".nft-card .nft-name").filter({ hasText: "Ape #001" }).first(),
  80  |   ).toBeVisible();
  81  |   await page.goto("/nfts/nft-001");
  82  |   await expect(page.getByRole("heading", { name: /Ape #001/i })).toBeVisible();
  83  | });
  84  | 
  85  | test("perfil do criador abre com estatísticas, coleções e obras navegáveis", async ({
  86  |   page,
  87  | }) => {
  88  |   await page.goto("/criadores");
  89  |   await expect(
  90  |     page.getByRole("heading", { name: "Conheça os criadores." }),
  91  |   ).toBeVisible();
  92  |   await expect(page.locator(".creator-card").first()).toBeVisible();
  93  | 
  94  |   const creatorCard = page.locator(".creator-card").first();
  95  |   const creatorName = (await creatorCard.locator("h3").innerText()).trim();
  96  |   await creatorCard.click();
  97  | 
  98  |   await expect(page).toHaveURL(/\/criadores\//);
  99  |   await expect(
  100 |     page.getByRole("heading", { name: creatorName, exact: true }),
  101 |   ).toBeVisible();
  102 |   await expect(page.locator(".creator-profile-stats")).toContainText("obras");
  103 |   await expect(page.locator(".creator-profile-stats")).toContainText("coleção");
  104 |   await expect(page.locator(".creator-profile-collections a").first()).toBeVisible();
  105 |   await expect(page.locator(".creator-work-grid .nft-card").first()).toBeVisible();
  106 | 
  107 |   await page.locator(".creator-work-grid .nft-name").first().click();
  108 |   await expect(page).toHaveURL(/\/nfts\/nft-/);
  109 |   await expect(page.getByRole("heading", { name: /#\d{3}/ })).toBeVisible();
  110 | });
  111 | 
  112 | test("Mercado explora coleções e conecta ao catálogo filtrado", async ({
  113 |   page,
  114 | }) => {
  115 |   await page.goto("/mercado");
  116 |   await expect(
  117 |     page.getByRole("heading", { name: "Explore o universo digital." }),
  118 |   ).toBeVisible();
  119 |   await expect(page.locator(".collection-card")).toHaveCount(5);
  120 | 
  121 |   const genesis = page.getByRole("link", {
  122 |     name: /Explorar coleção KURIO Genesis, 48 NFTs/i,
  123 |   });
  124 |   await expect(genesis.locator(".collection-card-art img")).toHaveCount(4);
  125 | 
> 126 |   await page.getByRole("searchbox", { name: "Buscar coleções ou criadores" }).fill(
      |                                                                               ^ Error: locator.fill: Test timeout of 30000ms exceeded.
  127 |     "neoarchive",
  128 |   );
  129 |   await expect(page.locator(".collection-card")).toHaveCount(1);
  130 |   await expect(
  131 |     page.getByRole("heading", { name: "Dreamscape" }),
  132 |   ).toBeVisible();
  133 | 
  134 |   await page.getByRole("searchbox", { name: "Buscar coleções ou criadores" }).fill("");
  135 |   await genesis.click();
  136 |   await expect(page).toHaveURL(/colecao=/);
  137 |   await expect(page.locator(".result-count")).toContainText(
  138 |     "48 obras encontradas",
  139 |   );
  140 | 
  141 |   await page.locator(".nft-card .nft-name").first().click();
  142 |   await expect(page.getByRole("heading", { name: /#\d{3}/ })).toBeVisible();
  143 |   await page.getByRole("link", { name: "KURIO Genesis" }).click();
  144 |   await expect(page).toHaveURL(/colecao=/);
  145 |   await expect(page.locator(".result-count")).toContainText(
  146 |     "48 obras encontradas",
  147 |   );
  148 | });
  149 | 
  150 | test("navegação principal abre o Mercado e a página não transborda", async ({
  151 |   page,
  152 | }) => {
  153 |   await page.goto("/");
  154 |   const mobileNav = page.getByRole("navigation", {
  155 |     name: "Navegação mobile",
  156 |   });
  157 |   const marketLink = (page.viewportSize()?.width ?? Infinity) <= 720
  158 |     ? mobileNav.getByRole("link", { name: "Mercado" })
  159 |     : page.getByRole("navigation", { name: "Principal" }).getByRole("link", {
  160 |         name: "Mercado",
  161 |       });
  162 |   await marketLink.click();
  163 |   await expect(page).toHaveURL(/\/mercado$/);
  164 |   await expect(
  165 |     page.getByRole("heading", { name: "Explore o universo digital." }),
  166 |   ).toBeVisible();
  167 | 
  168 |   for (const width of [390, 768, 1440]) {
  169 |     await page.setViewportSize({ width, height: 900 });
  170 |     await expect
  171 |       .poll(() =>
  172 |         page.evaluate(
  173 |           () => document.documentElement.scrollWidth <= window.innerWidth,
  174 |         ),
  175 |       )
  176 |       .toBe(true);
  177 |   }
  178 | });
  179 | 
  180 | test("Mercado mostra estados de erro e catálogo vazio", async ({ page }) => {
  181 |   await page.goto("/mercado?mockScenario=empty-catalog");
  182 |   await expect(
  183 |     page.getByRole("heading", { name: "Nenhuma coleção encontrada." }),
  184 |   ).toBeVisible();
  185 |   await expect(page.locator(".collection-card")).toHaveCount(0);
  186 | 
  187 |   await page.goto("/mercado?mockScenario=server-error");
  188 |   await expect(
  189 |     page.getByRole("heading", {
  190 |       name: "Não foi possível carregar as coleções.",
  191 |     }),
  192 |   ).toBeVisible();
  193 | });
  194 | 
  195 | test("categorias combinam com rede e persistem após refresh", async ({
  196 |   page,
  197 | }, testInfo) => {
  198 |   await page.goto("/");
  199 |   if (testInfo.project.name === "mobile") {
  200 |     await page.getByRole("button", { name: /FILTROS/i }).click();
  201 |   }
  202 |   const musicFilter = page.getByRole("checkbox", { name: /Música/ });
  203 |   await musicFilter.scrollIntoViewIfNeeded();
  204 |   const filterScrollPosition = await page.evaluate(() => window.scrollY);
  205 |   await musicFilter.check();
  206 |   await expect
  207 |     .poll(() => page.evaluate(() => window.scrollY))
  208 |     .toBe(filterScrollPosition);
  209 |   await page.getByRole("checkbox", { name: "Ethereum" }).check();
  210 |   await expect(page).toHaveURL(/categoria=.*musica/);
  211 |   await expect(page.locator(".result-count")).toContainText(
  212 |     "22 obras encontradas",
  213 |   );
  214 |   await page.goBack();
  215 |   await expect(page).toHaveURL(/categoria=.*musica/);
  216 |   await expect(page.getByRole("checkbox", { name: /Música/ })).toBeChecked();
  217 |   await expect(
  218 |     page.getByRole("checkbox", { name: "Ethereum" }),
  219 |   ).not.toBeChecked();
  220 |   await expect(page.locator(".result-count")).toContainText(
  221 |     "65 obras encontradas",
  222 |   );
  223 |   await page.goForward();
  224 |   await expect(page.getByRole("checkbox", { name: "Ethereum" })).toBeChecked();
  225 |   await expect(page.locator(".result-count")).toContainText(
  226 |     "22 obras encontradas",
```